package travail;

import java.io.Serializable;
import java.util.Objects;

public class SpecialisationPK implements Serializable {

    private static final long serialVersionUID = 1L;

    private int technicien;
    private String type;

    // Constructeurs
    public SpecialisationPK() {}

    public SpecialisationPK(int technicien, String type) {
        this.technicien = technicien;
        this.type = type;
    }

    // Getters et Setters
    public int getTechnicienMatricule() {
        return technicien;
    }

    public void setTechnicienMatricule(int technicienMatricule) {
        this.technicien = technicienMatricule;
    }

    public String getTypeNom() {
        return type;
    }

    public void setTypeNom(String typeNom) {
        this.type = typeNom;
    }

    // Override equals et hashCode
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SpecialisationPK that = (SpecialisationPK) o;
        return technicien == that.technicien && Objects.equals(type, that.type);
    }

    @Override
    public int hashCode() {
        return Objects.hash(technicien, type);
    }
}
