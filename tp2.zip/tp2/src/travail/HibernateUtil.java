package travail;

import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

public class HibernateUtil {

    private static SessionFactory sessionFactory;
    private static ServiceRegistry serviceRegistry;

    // Méthode pour obtenir la SessionFactory
    public static SessionFactory buildSessionFactory() {
        if (sessionFactory == null) {
            try {
                // Créer la configuration
                Configuration configuration = new Configuration();
               // configuration.addAnnotatedClass(Client.class);
                configuration.addAnnotatedClass(Test.class); // Ajoute la classe d'entité Test
               configuration.addAnnotatedClass(Examen.class);
               configuration.addAnnotatedClass(Type.class);
               configuration.addAnnotatedClass(Adresse.class);
               configuration.addAnnotatedClass(Employe.class);
               configuration.addAnnotatedClass(Technicien.class);
               configuration.addAnnotatedClass(Pilote.class);
               configuration.addAnnotatedClass(Avion.class);
               configuration.addAnnotatedClass(AvionTest.class);
               configuration.addAnnotatedClass(Examination.class);
               configuration.addAnnotatedClass(Piloter.class);
               configuration.addAnnotatedClass(Specialisation.class);
               configuration.addAnnotatedClass(Qualification.class);
               configuration.addAnnotatedClass(Reparation.class);

                configuration.configure("hibernate.cfg.xml");  // Charge le fichier de configuration Hibernate

                // Appliquer les paramètres à la registry
                serviceRegistry = new StandardServiceRegistryBuilder()
                    .applySettings(configuration.getProperties())
                    .build();

                // Construire la SessionFactory
                sessionFactory = configuration.buildSessionFactory(serviceRegistry);
                
                System.out.println("SessionFactory créée avec succès");
            } catch (Throwable ex) {
                // Si une erreur se produit, détruire le serviceRegistry
                if (serviceRegistry != null) {
                    StandardServiceRegistryBuilder.destroy(serviceRegistry);
                }
                System.err.println("Erreur lors de la création de la SessionFactory : " + ex);
                throw new ExceptionInInitializerError(ex);
            }
        }
        return sessionFactory;
    }

    // Méthode pour fermer la SessionFactory
    public static void shutdown() {
        // Fermer la SessionFactory
        if (sessionFactory != null) {
            sessionFactory.close();
        }
    }
}
