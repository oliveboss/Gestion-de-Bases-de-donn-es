package travail;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@IdClass(QualificationPK.class) // Annotation pour indiquer la clé composite
public class Qualification implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @ManyToOne
    @JoinColumn(name = "Pilote_matricule", referencedColumnName = "matricule", nullable = false)
    private Pilote pilote;

    @Id
    @ManyToOne
    @JoinColumn(name = "Type_nom", referencedColumnName = "nom", nullable = false)
    private Type type;

    // Constructeurs
    public Qualification() {}

    public Qualification(Pilote pilote, Type type) {
        this.pilote = pilote;
        this.type = type;
    }

    // Getters et Setters
    public Pilote getPilote() {
        return pilote;
    }

    public void setPilote(Pilote pilote) {
        this.pilote = pilote;
    }

    public Type getType() {
        return type;
    }

    public void setType(Type type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "Qualification{" +
                "pilote=" + pilote +
                ", type=" + type +
                '}';
    }
}
