package travail;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
public class Examen {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Auto-increment pour le matricule
    @Column(name="identifiant")
    private int id;

    @Column( length = 45)
    private String description;

    @Column(name = "Examencol", columnDefinition = "TEXT")
    private String examencol;
public Examen() {};
 // Constructeur avec les trois attributs
    public Examen( int id ,String description, String Examencol) {
        this.id=id;
    	this.description = description;
        this.examencol = Examencol;
    }
    // Getters et setters

    public Examen(String description, String Examencol) {
		// TODO Auto-generated constructor stub
    	this.description = description;
        this.examencol = Examencol;
	}
	public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getExamencol() {
        return examencol;
    }

    public void setExamencol(String examencol) {
        this.examencol = examencol;
    }

    // toString()
    @Override
    public String toString() {
        return "Examen [id=" + id + ", description=" + description + ", examencol=" + examencol + "]";
    }
}
