package travail;

import javax.validation.Constraint;
import javax.validation.Payload;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Constraint(validatedBy = CodePostalValidator.class)
@Target({ ElementType.FIELD, ElementType.METHOD, ElementType.PARAMETER, ElementType.ANNOTATION_TYPE })
@Retention(RetentionPolicy.RUNTIME)
public @interface CodePostal {
    String message() default "Code postal invalide. Il doit respecter l'un des formats : XAX AXA, XAX-AXA, ou XAXAXA.";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}