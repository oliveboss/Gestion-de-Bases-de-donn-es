package travail;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@IdClass(PiloterPK.class) // Utilisation d'une clé composite
public class Piloter implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @ManyToOne
    @JoinColumn(name = "Pilote_matricule", referencedColumnName = "matricule", nullable = false)
    private Pilote pilote; // Référence à l'entité Pilote

    @Id
    @ManyToOne
    @JoinColumn(name = "Avion_matricule", referencedColumnName = "matricule", nullable = false)
    private Avion avion; // Référence à l'entité Avion

    // Constructeur par défaut
    public Piloter() {}

    // Constructeur avec paramètres
    public Piloter(Pilote pilote, Avion avion) {
        this.pilote = pilote;
        this.avion = avion;
    }

    // Getters et Setters
    public Pilote getPilote() {
        return pilote;
    }

    public void setPilote(Pilote pilote) {
        this.pilote = pilote;
    }

    public Avion getAvion() {
        return avion;
    }

    public void setAvion(Avion avion) {
        this.avion = avion;
    }

    @Override
    public String toString() {
        return "Piloter{" +
                "pilote=" + pilote +
                ", avion=" + avion +
                '}';
    }
}
