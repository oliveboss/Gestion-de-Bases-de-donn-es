package travail;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@IdClass(ReparationPK.class) // Utilisation de la clé composite
public class Reparation implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @ManyToOne
    @JoinColumn(name = "Avion_matricule", referencedColumnName = "matricule", nullable = false)
    private Avion avion; // Référence vers l'entité Avion

    @Id
    @ManyToOne
    @JoinColumn(name = "Technicien_matricule", referencedColumnName = "matricule", nullable = false)
    private Technicien technicien; // Référence vers l'entité Technicien

    @Column(name = "CoutTotal", precision = 6, scale = 2)
    private BigDecimal coutTotal; // Coût total de la réparation

    @Column(name = "Date", nullable = false)
    private Date date; // Date de la réparation

    // Constructeurs
    public Reparation() {}

    public Reparation(Avion avion, Technicien technicien, BigDecimal coutTotal, Date date) {
        this.avion = avion;
        this.technicien = technicien;
        this.coutTotal = coutTotal;
        this.date = date;
    }

    // Getters et Setters
    public Avion getAvion() {
        return avion;
    }

    public void setAvion(Avion avion) {
        this.avion = avion;
    }

    public Technicien getTechnicien() {
        return technicien;
    }

    public void setTechnicien(Technicien technicien) {
        this.technicien = technicien;
    }

    public BigDecimal getCoutTotal() {
        return coutTotal;
    }

    public void setCoutTotal(BigDecimal coutTotal) {
        this.coutTotal = coutTotal;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    @Override
    public String toString() {
        return "Reparation{" +
                "avion=" + avion +
                ", technicien=" + technicien +
                ", coutTotal=" + coutTotal +
                ", date=" + date +
                '}';
    }
}
