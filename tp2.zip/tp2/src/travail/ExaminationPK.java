package travail;

import java.io.Serializable;
import java.util.Objects;

public class ExaminationPK implements Serializable {

    private static final long serialVersionUID = 1L;

    private int pilote; // Correspond au champ 'pilote' dans l'entité Examination
    private int examen; // Correspond au champ 'examen' dans l'entité Examination

    public ExaminationPK() {}

    public ExaminationPK(int pilote, int examen) {
        this.pilote = pilote;
        this.examen = examen;
    }

    // Getters et Setters
    public int getPilote() {
        return pilote;
    }

    public void setPilote(int pilote) {
        this.pilote = pilote;
    }

    public int getExamen() {
        return examen;
    }

    public void setExamen(int examen) {
        this.examen = examen;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ExaminationPK that = (ExaminationPK) o;
        return pilote == that.pilote && examen == that.examen;
    }

    @Override
    public int hashCode() {
        return Objects.hash(pilote, examen);
    }
}
