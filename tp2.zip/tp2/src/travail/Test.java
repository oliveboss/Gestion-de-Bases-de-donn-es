package travail;
import java.math.BigDecimal;

import javax.persistence.*;

@Entity
@Table(name = "test")
public class Test {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Auto-increment pour le matricule
    @Column(name = "numero" ,nullable = false)
    private int numero;

    @Column(name = "nom", nullable = false)
    private String nom;

    @Column(name = "seuil", nullable = false)
    private BigDecimal seuil;

    // Getters et setters
    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public BigDecimal getSeuil() {
        return seuil;
    }

    public void setSeuil(BigDecimal seuil) {
        this.seuil = seuil;
    }

    // Constructeur par défaut
    public Test() {}

    // Constructeur avec paramètres
    public Test(int numero, String nom, BigDecimal seuil) {
        this.numero = numero;
        this.nom = nom;
        this.seuil = seuil;
    }

	public Test(String nom, BigDecimal seuil) {
		// TODO Auto-generated constructor stub
		this.nom = nom;
        this.seuil = seuil;
	}

	

	
}
