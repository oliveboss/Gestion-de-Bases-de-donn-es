package travail;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.Indexed;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.FullTextField;

@Entity
@Indexed
public class Adresse {

    @Id
     // Auto-increment pour le matricule
    @Column(name = "id", nullable = false)
    private int id;

    @Column(name = "numeroRue", nullable = false)
    private int numeroRue;

    @Column(name = "nomRue", length = 255)
    @FullTextField(analyzer = "default")
    private String nomRue;

    @Column(name = "ville", nullable = false, length = 255)
    @FullTextField
    private String ville;

    @Column(name = "codePostal", nullable = false, length = 45)
    @CodePostal
    private String codePostal;

    @Column(name = "province", nullable = false, length = 255)
    // Application de la validation personnalisée
    private String province;

    @Column(name = "pays", nullable = false, length = 255)
    private String pays;

    // Constructeur par défaut
    public Adresse() {}

    // Constructeur avec arguments
    public Adresse(int id,int numeroRue, String nomRue, String ville, String codePostal, String province, String pays) {
        this.id=id;
    	this.numeroRue = numeroRue;
        this.nomRue = nomRue;
        this.ville = ville;
        this.codePostal = codePostal;
        this.province = province;
        this.pays = pays;
    }

    // Getters et setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getNumeroRue() {
        return numeroRue;
    }

    public void setNumeroRue(int numeroRue) {
        this.numeroRue = numeroRue;
    }

    public String getNomRue() {
        return nomRue;
    }

    public void setNomRue(String nomRue) {
        this.nomRue = nomRue;
    }

    public String getVille() {
        return ville;
    }

    public void setVille(String ville) {
        this.ville = ville;
    }

    public String getCodePostal() {
        return codePostal;
    }

    public void setCodePostal(String codePostal) {
        this.codePostal = codePostal;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getPays() {
        return pays;
    }

    public void setPays(String pays) {
        this.pays = pays;
    }

    @Override
    public String toString() {
        return "Adresse{" +
                "id=" + id +
                ", numeroRue=" + numeroRue +
                ", nomRue='" + (nomRue != null ? nomRue : "N/A") + '\'' +
                ", ville='" + ville + '\'' +
                ", codePostal='" + codePostal + '\'' +
                ", province='" + province + '\'' +
                ", pays='" + pays + '\'' +
                '}';
    }
}
