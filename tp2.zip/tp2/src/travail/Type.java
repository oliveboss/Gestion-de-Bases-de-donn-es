package travail;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Type {

    @Id
    @Column(name = "nom", nullable = false, length = 45)
    private String nom;  // Clé primaire

    @Column(name = "capacite")
    private int capacite;

    @Column(name = "poids",  precision = 6, scale = 2)
    private double poids;

    @Column(name = "rayonAction",  precision = 6, scale = 2)
    private double rayonAction;

    // Constructeur sans argument
    public Type() {}

    // Constructeur avec arguments
    public Type(String nom, int capacite, double poids, double rayonAction) {
        this.nom = nom;
        this.capacite = capacite;
        this.poids = poids;
        this.rayonAction = rayonAction;
    }

    // Getters et setters
    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public int getCapacite() {
        return capacite;
    }

    public void setCapacite(int capacite) {
        this.capacite = capacite;
    }

    public double getPoids() {
        return poids;
    }

    public void setPoids(double poids) {
        this.poids = poids;
    }

    public double getRayonAction() {
        return rayonAction;
    }

    public void setRayonAction(double rayonAction) {
        this.rayonAction = rayonAction;
    }

    @Override
    public String toString() {
        return "Type{" +
                "nom='" + nom + '\'' +
                ", capacite=" + capacite +
                ", poids=" + poids +
                ", rayonAction=" + rayonAction +
                '}';
    }
}
