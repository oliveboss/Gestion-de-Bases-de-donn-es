package travail;

import java.io.Serializable;
import java.util.Objects;

public class PiloterPK implements Serializable {

    private static final long serialVersionUID = 1L;

    private int pilote; // Correspond à Pilote_matricule
    private int avion;  // Correspond à Avion_matricule

    public PiloterPK() {}

    public PiloterPK(int pilote, int avion) {
        this.pilote = pilote;
        this.avion = avion;
    }

    public int getPilote() {
        return pilote;
    }

    public void setPilote(int pilote) {
        this.pilote = pilote;
    }

    public int getAvion() {
        return avion;
    }

    public void setAvion(int avion) {
        this.avion = avion;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PiloterPK that = (PiloterPK) o;
        return pilote == that.pilote && avion == that.avion;
    }

    @Override
    public int hashCode() {
        return Objects.hash(pilote, avion);
    }
}
