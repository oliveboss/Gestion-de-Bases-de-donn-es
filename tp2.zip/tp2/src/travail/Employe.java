package travail;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
public class Employe {

    @Id
    @Column(name = "matricule", nullable = false)
    private int matricule;

    @Column(name = "nom", length = 45)
    private String nom;

    @Column(name = "prenom",  length = 45)
    private String prenom;

    @ManyToOne
    @JoinColumn(name = "adresse", nullable = false) // Clé étrangère vers la table Adresse
    private Adresse adresse;

    @Column(name = "tel",length = 45)
    private String tel;

    @Column(name = "dateEngagement", nullable = false)
    @Temporal(TemporalType.DATE) // Pour gérer le type `Date`
    private Date dateEngagement;

    @Column(name = "salaire", nullable = false, precision = 6, scale = 2)
    private BigDecimal salaire;

    // Constructeur par défaut
    public Employe() {}

    // Constructeur avec arguments
    public Employe(int matricule,String nom, String prenom, Adresse adresse, String tel, Date dateEngagement, BigDecimal salaire) {
       this.matricule=matricule;
    	this.nom = nom;
        this.prenom = prenom;
        this.adresse = adresse;
        this.tel = tel;
        this.dateEngagement = dateEngagement;
        this.salaire = salaire;
    }

    // Getters et setters
    public int getMatricule() {
        return matricule;
    }

    public void setMatricule(int matricule) {
        this.matricule = matricule;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public Adresse getAdresse() {
        return adresse;
    }

    public void setAdresse(Adresse adresse) {
        this.adresse = adresse;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public Date getDateEngagement() {
        return dateEngagement;
    }

    public void setDateEngagement(Date dateEngagement) {
        this.dateEngagement = dateEngagement;
    }

    public BigDecimal getSalaire() {
        return salaire;
    }

    public void setSalaire(BigDecimal salaire) {
        this.salaire = salaire;
    }

    @Override
    public String toString() {
        return "Employe{" +
                "matricule=" + matricule +
                ", nom='" + nom + '\'' +
                ", prenom='" + prenom + '\'' +
                ", adresse=" + adresse +
                ", tel='" + tel + '\'' +
                ", dateEngagement=" + dateEngagement +
                ", salaire=" + salaire +
                '}';
    }
}
