package travail;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@IdClass(SpecialisationPK.class) // Annotation pour indiquer la clé composite
public class Specialisation implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @ManyToOne
    @JoinColumn(name = "Technicien_matricule", referencedColumnName = "matricule", nullable = false)
    private Technicien technicien;

    @Id
    @ManyToOne
    @JoinColumn(name = "Type_nom", referencedColumnName = "nom", nullable = false)
    private Type type;

    // Constructeurs
    public Specialisation() {}

    public Specialisation(Technicien technicien, Type type) {
        this.technicien = technicien;
        this.type = type;
    }

    // Getters et Setters
    public Technicien getTechnicien() {
        return technicien;
    }

    public void setTechnicien(Technicien technicien) {
        this.technicien = technicien;
    }

    public Type getType() {
        return type;
    }

    public void setType(Type type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "Specialisation{" +
                "technicien=" + technicien +
                ", type=" + type +
                '}';
    }
}
