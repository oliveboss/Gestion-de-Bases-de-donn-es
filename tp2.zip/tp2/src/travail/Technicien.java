package travail;

import java.math.BigDecimal;
import java.sql.Date;

import javax.persistence.*;

@Entity
@PrimaryKeyJoinColumn(name = "matricule") // Indique que le matricule est la clé primaire partagée avec Employe
public class Technicien extends Employe {

    @Id
    @Column(name = "matricule")
    private int matricule; // Matricule unique pour le technicien

   /* // Constructeur par défaut
    public Technicien() {
        super(); // Appel au constructeur de la classe parente (Employe)
    }*/

    // Constructeur avec paramètres
    public Technicien(int matricule ,String nom, String prenom, Adresse adresse, String tel, java.util.Date date, BigDecimal salaire) {
        super(matricule,nom, prenom, adresse, tel, date, salaire);
   this.matricule=matricule ;
    }

    // Getters et Setters
    public int getMatricule() {
        return matricule;
    }

    public void setMatricule(int matricule) {
        this.matricule = matricule;
    }

    @Override
    public String toString() {
        return "Technicien{" +
                "matricule=" + matricule +
                ", nom=" + getNom() +
                ", prenom=" + getPrenom() +
                ", adresse=" + getAdresse() +
                ", tel=" + getTel() +
                ", dateEngagement=" + getDateEngagement() +
                ", salaire=" + getSalaire() +
                '}';
    }
}
