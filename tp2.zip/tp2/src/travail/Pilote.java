

package travail;

import java.math.BigDecimal;
import java.sql.Date;
import javax.persistence.*;

@Entity
@Inheritance(strategy = InheritanceType.JOINED) // Héritage avec une table par entité
public class Pilote extends Employe {

    @Id
    @Column(name = "matricule")
    private int matricule; // Matricule unique pour le pilote

    // Constructeur par défaut
    /*public Pilote() {
        super(); // Appel au constructeur de la classe parente (Employe)
    }
*/
    // Constructeur avec paramètres
    public Pilote(int matricule, String nom, String prenom, Adresse adresse, String tel, java.util.Date date, BigDecimal salaire) {
        super(matricule, nom, prenom, adresse, tel, date, salaire);
   this.matricule=matricule;
    }

    // Getters et Setters
    public int getMatricule() {
        return matricule;
    }

    public void setMatricule(int matricule) {
        this.matricule = matricule;
    }

    @Override
    public String toString() {
        return "Pilote{" +
                "matricule=" + matricule +
                ", nom=" + getNom() +
                ", prenom=" + getPrenom() +
                ", adresse=" + getAdresse() +
                ", tel=" + getTel() +
                ", dateEngagement=" + getDateEngagement() +
                ", salaire=" + getSalaire() +
                '}';
    }
}
