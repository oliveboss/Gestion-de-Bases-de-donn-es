package travail;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class CodePostalValidator implements ConstraintValidator<CodePostal, String> {

	private static final String CODE_POSTAL_REGEX = "^[A-Z]\\d[A-Z] ?\\d[A-Z]\\d$|^[A-Z]\\d[A-Z]-\\d[A-Z]\\d$|^[A-Z]\\d[A-Z]\\d[A-Z]\\d$";
    @Override
    public void initialize(CodePostal constraintAnnotation) {
        // Peut rester vide si aucune initialisation spécifique n'est requise.
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        if (value == null) {
            return false; // Si le code postal est null, il est considéré comme invalide.
        }
        return value.matches(CODE_POSTAL_REGEX);
    }
}