package travail;

import javax.persistence.*;

@Entity
public class Avion {

    @Id
    @Column(name = "matricule")
    private int matricule; // Matricule de l'avion (clé primaire)

    @ManyToOne
    @JoinColumn(name = "Type_nom", referencedColumnName = "nom", nullable = false)
    private Type type; // Type de l'avion (relation avec la table Type)

    // Constructeur
    public Avion() {}

    public Avion(int matricule, Type type) {
        this.matricule = matricule;
        this.type = type;
    }

    // Getters et setters
    public int getMatricule() {
        return matricule;
    }

    public void setMatricule(int matricule) {
        this.matricule = matricule;
    }

    public Type getType() {
        return type;
    }

    public void setType(Type type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "Avion{" +
                "matricule=" + matricule +
                ", type=" + type.getNom() +
                '}';
    }
}
