package travail;

import java.io.Serializable;
import java.util.Objects;

public class QualificationPK implements Serializable {

    private static final long serialVersionUID = 1L;

    private int pilote;
    private String type;

    // Constructeurs
    public QualificationPK() {}

    public QualificationPK(int pilote, String type) {
        this.pilote = pilote;
        this.type= type;
    }

    // Getters et Setters
    public int getPiloteMatricule() {
        return pilote;
    }

    public void setPiloteMatricule(int piloteMatricule) {
        this.pilote = piloteMatricule;
    }

    public String getTypeNom() {
        return type;
    }

    public void setTypeNom(String typeNom) {
        this.type = typeNom;
    }

    // Override equals et hashCode
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        QualificationPK that = (QualificationPK) o;
        return pilote == that.pilote && Objects.equals(type, that.type);
    }

    @Override
    public int hashCode() {
        return Objects.hash(pilote, type);
    }
}
