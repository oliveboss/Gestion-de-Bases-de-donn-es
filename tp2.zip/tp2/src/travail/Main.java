package travail;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.HibernateException;
import org.hibernate.search.mapper.orm.Search;
import org.hibernate.search.mapper.orm.session.SearchSession;
import org.hibernate.search.engine.search.query.SearchResult;

import java.math.BigDecimal;
import java.util.Date;

import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import org.hibernate.search.engine.search.query.SearchResult;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.Indexed;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.FullTextField;
public class Main {
    public static void main(String[] args) {
        // Créer une SessionFactory via HibernateUtil
        SessionFactory factory = HibernateUtil.buildSessionFactory();
        // Créer un validateur
        ValidatorFactory validatorFactory = Validation.buildDefaultValidatorFactory();
        Validator validator = validatorFactory.getValidator();

        // Ouvrir une session
        Session session = factory.openSession();
        System.out.println("Session ouverte avec succès");

        try {
        	   session.beginTransaction();
        
        	   
    /*	
        	
        	   
        	     // Création d'une nouvelle adresse
        Adresse nouvelleAdresse = new Adresse(
            1,                // ID
            123,              // Numéro de rue
            "Rue des Fleurs", // Nom de rue
            "Montréal",       // Ville
            "H2X 1Y4",        // Code postal
            "Québec",         // Province
            "Canada"          // Pays
            
        );
        	    session.save(nouvelleAdresse);
        System.out.println("Adresse sauvegardée avec succès.");

          
        	   
        	   
      
        	// Création d'une nouvelle instance de Test
               Test nouveauTest = new Test(
                                      // Numéro
                   "Test de Performance",      // Nom
                   new BigDecimal("7")     // Seuil
               );
               session.save(nouveauTest);
               System.out.println("Test  sauvegardé avec succès.");
               
             
        	   
        	 
        	   
        	   
       
        	   // Création d'une nouvelle instance de Examen
        	    Examen nouvelExamen = new Examen(
        	                              // ID de l'examen
        	        "Examen de fin de session", // Description
        	        "Session Automne 2024"      // Examencol
        	    );
        	    session.save(nouvelExamen);
                System.out.println("Examen  sauvegardé avec succès.");
                  
        	
        	   
        	   
        	   
      
        	// Création d'une nouvelle instance de Type
        	    Type nouveauType = new Type(
        	        "Avion Cargo",     // Nom
        	        2,               // Capacité
        	        8,           // Poids
        	        7            // Rayon d'action
        	    );
        	    session.save(nouveauType);
                System.out.println("Type  sauvegardé avec succès.");
             
        	 
        	   
        	   
       
        	// Création d'un employé
               Employe nouvelEmploye = new Employe(
                   1001,                     // Matricule
                   "Dupont",                 // Nom
                   "Jean",                   // Prénom
                   nouvelleAdresse,                  // Adresse (objet Adresse)
                   "+33 6 12 34 56 78",      // Téléphone
                   new Date(),               // Date d'engagement (aujourd'hui)
                   new BigDecimal("8") // Salaire
               );
        	    session.save(nouvelEmploye);
        System.out.println("Employe sauvegardé avec succès.");
        	   
        	   
        	   
        	   
    
        	  
        	   
        	   // Création d'un Pilote
        Pilote nouveauPilote = new Pilote(
        		1002,                        // Matricule
        	    "Dupont",                    // Nom
        	    "Jean",                      // Prénom
        	    nouvelleAdresse,             // Adresse (objet Adresse)
        	    "+33 6 12 34 56 78",         // Téléphone
        	    new Date(),                  // Date d'engagement (aujourd'hui)
        	    new BigDecimal("5")    // Salairev
        	   
        	);           
        
        session.save(nouveauPilote);
        System.out.println("Pilote sauvegardé avec succès.");
               
              
               
               
               
           
        	   // Création d'un technicien
               Technicien nouveauTechnicien = new Technicien(
                   10,                     // Matricule
                   "Dupont",                 // Nom
                   "Jean",                   // Prénom
                  nouvelleAdresse,                  // Adresse (objet Adresse)
                   "+33 6 12 34 56 78",      // Téléphone
                   new Date(),               // Date d'engagement (aujourd'hui)
                   new BigDecimal("4") // Salaire
               );
                session.save(nouveauTechnicien);
        System.out.println("Technicien sauvegardé avec succès.");
               
             
        	   
        	   
        	   
    
        	   // Création d'une spécialisation avec un technicien et un type
               Specialisation specialisation = new Specialisation(nouveauTechnicien, nouveauType);
        	  session.save(specialisation);
        System.out.println("Specialisation sauvegardée avec succès.");
        	   
        	 
        	   
        	   
        	   

        	   
        	// Création d'un avion
               Avion avion = new Avion(
                   12345,               // Matricule de l'avion
                   nouveauType            // Type de l'avion
               );
               
                 session.save(avion);
        System.out.println("Avion sauvegardé avec succès.");
        	 
        	   
        	
        	
        	   
        	   
      
        	// Création de l'objet AvionTest
        	   // Création de la date du test
               //Date date =    new Date(); 
               Date dateTeste = new Date();
               AvionTest avionTest = new AvionTest(avion, nouveauTest, dateTeste);

        	     session.save(avionTest);
        System.out.println("avionTest sauvegardé avec succès.");
        	
        	   
        	   
        	   
        	   
        	   
  
        	   
        	   // Création de l'objet Piloter
               Piloter piloter = new Piloter(
                   nouveauPilote,    // Pilote qui pilote l'avion
                   avion      // L'avion piloté
               );
                 session.save(piloter);
        System.out.println("Piloter sauvegardé avec succès.");
              
        	   
        	   
        	   
        	   
        	   
        
        	// Création de la date de l'examen
               Date dateExamen = new Date();  // Date actuelle

               // Création du rapport de l'examen
               String rapport = "Le pilote a réussi l'examen théorique avec succès.";

               // Création de l'objet Examination
               Examination examination = new Examination(
                   nouveauPilote,      // Pilote qui passe l'examen
                   nouvelExamen,      // L'examen effectué
                   dateExamen,  // La date de l'examen
                   rapport      // Le rapport de l'examen
               );
             session.save(examination);
        System.out.println("examination sauvegardée avec succès.");
        	
        	   
        	   
        	   
        	   
        	   
     
        	   // Création de l'objet Qualification
               Qualification qualification = new Qualification(nouveauPilote, nouveauType);
        	     session.save(qualification);
        System.out.println("qualification sauvegardé avec succès.");
        	   
        	   
        	  
        	   
        	   
        	   
        	// Création du coût total de la réparation
               BigDecimal coutTotal = new BigDecimal("8");

               // Création de la date de la réparation
               Date dateReparation = new Date();  // Date actuelle

               // Création de l'objet Reparation
               Reparation reparation = new Reparation(avion, nouveauTechnicien, coutTotal, dateReparation);
  session.save(reparation);
        System.out.println("reparation sauvegardé avec succès.");
        	   
        	  
        	 
        	   
        	   
        	   
        	   
        	   
        	   
     */   	   
        	   
        	   
        	   
        	   
        	   
        	   
        	 
        	  
            // Créer une nouvelle adresse avec des données valides
            Adresse adresse = new Adresse(
                14,                  // ID
                123,                // Numéro de rue
                "Rue des Lilas",    // Nom de rue
                "Montréal",         // Ville
                "H1OLIVIA-1B2",          // Code postal
                "Québec",           // Province
                "Canada"            // Pays
            );

            
            
            
            
            
            
            
            
            // Valider l'adresse
            var violations = validator.validate(adresse);
            if (!violations.isEmpty()) {
                // Afficher les erreurs de validation
                violations.forEach(violation -> System.out.println(violation.getMessage()));
            } else {
                // Démarrer une transaction
             
                // Sauvegarder l'entité dans la base
                session.save(adresse);
                System.out.println("Adresse sauvegardée avec succès.");
               
               
               }
        	  
        	   
        	   
        	   
        	   
        	   //    **********************Utilisation de hibernate search 
        	   
        	   // Utilisation de hibernateserach 
        	
        	   
        	   // Recherche d'une adresse avec le terme 'Paris'
        	   // Utiliser SearchSession pour rechercher avec Hibernate Search
              
        	  /* 
        	   SearchSession searchSession = Search.session(session);
              // searchSession.massIndexer(Adresse.class).start(); // Cela indexe toutes les adresses
               
              try {
				Search.session(session).massIndexer().startAndWait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			
			}
               // Recherche d'une adresse avec le terme 'Rue des Lilas'
               SearchResult<Adresse> result = searchSession.search(Adresse.class)
                       .where(f -> f.match().field("nomRue").matching("Rue des Fleurs"))
                       .fetchAll();

               // Affichage des résultats de la recherche

            // Vérification et affichage des résultats
            if (result.hits().isEmpty()) {
                System.out.println("Aucune adresse trouvée avec 'Rue des Lilas'.");
            } else {
                System.out.println("Résultats trouvés :");
                for (Adresse adresse : result.hits()) {
                    System.out.println(adresse); // Assurez-vous que la méthode toString() est bien définie dans la classe Adresse
                }
            }

            // Affichage du total des résultats
            System.out.println("Total des adresses trouvées : " + result.total().hitCount());
 ;
*/
               
            
        	   
        	   
        	   session.getTransaction().commit();
            
        } catch (HibernateException e) {
            // En cas d'erreur, rollback de la transaction
            if (session.getTransaction() != null) {
                session.getTransaction().rollback();
            }
            e.printStackTrace();
        } finally {
            // Fermeture de la session
            session.close();
        }
    }
}