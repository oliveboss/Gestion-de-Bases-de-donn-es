package travail;

import javax.persistence.*;

import java.util.Objects;
import java.io.Serializable;
import java.util.Date;

@Entity
public class AvionTest implements Serializable{
    private static final long serialVersionUID = 1L; // Version de la sérialisation

    @Id
    @ManyToOne
    @JoinColumn(name = "Avion_matricule", referencedColumnName = "matricule", nullable = false)
    private Avion avion; // L'avion auquel est lié le test

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ManyToOne
    @JoinColumn(name = "Test_numero", referencedColumnName = "numero", nullable = false)
    private Test test; // Le test effectué sur l'avion

    @Column(name = "date", nullable = false)
    private Date date; // Date du test

    // Constructeur
   /* public AvionTest() {}*/

    public AvionTest(Avion avion, Test test, Date date) {
        this.avion = avion;
        this.test = test;
        this.date = date;
    }

    // Getters et setters
    public Avion getAvion() {
        return avion;
    }

    public void setAvion(Avion avion) {
        this.avion = avion;
    }

    public Test getTest() {
        return test;
    }

    public void setTest(Test test) {
        this.test = test;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AvionTest avionTest = (AvionTest) o;
        return Objects.equals(avion, avionTest.avion) &&
               Objects.equals(test, avionTest.test) &&
               Objects.equals(date, avionTest.date);
    }

    @Override
    public int hashCode() {
        return Objects.hash(avion, test, date);
    }

    @Override
    public String toString() {
        return "AvionTest{" +
                "avion=" + avion.getMatricule() +
                ", test=" + test.getNumero() +
                ", date=" + date +
                '}';
    }
}
