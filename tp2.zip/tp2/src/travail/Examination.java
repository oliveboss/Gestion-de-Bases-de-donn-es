package travail;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@IdClass(ExaminationPK.class) // Utilisation d'une clé composite
public class Examination implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @ManyToOne
    @JoinColumn(name = "Pilote_matricule", referencedColumnName = "matricule", nullable = false)
    private Pilote pilote; // Correspond à la clé primaire 'pilote' dans ExaminationPK

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Auto-increment pour le matricule
    @ManyToOne
    @JoinColumn(name = "Examen_identifiant", referencedColumnName = "identifiant", nullable = false)
    private Examen examen; // Correspond à la clé primaire 'examen' dans ExaminationPK

    @Column(name = "date", nullable = false)
    private Date date;

    @Column(name = "rapport", nullable = false, columnDefinition = "TEXT")
    private String rapport;

    public Examination() {}

    public Examination(Pilote pilote, Examen examen, Date date, String rapport) {
        this.pilote = pilote;
        this.examen = examen;
        this.date = date;
        this.rapport = rapport;
    }

    // Getters et Setters
    public Pilote getPilote() {
        return pilote;
    }

    public void setPilote(Pilote pilote) {
        this.pilote = pilote;
    }

    public Examen getExamen() {
        return examen;
    }

    public void setExamen(Examen examen) {
        this.examen = examen;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getRapport() {
        return rapport;
    }

    public void setRapport(String rapport) {
        this.rapport = rapport;
    }

    @Override
    public String toString() {
        return "Examination{" +
                "pilote=" + pilote +
                ", examen=" + examen +
                ", date=" + date +
                ", rapport='" + rapport + '\'' +
                '}';
    }
}
