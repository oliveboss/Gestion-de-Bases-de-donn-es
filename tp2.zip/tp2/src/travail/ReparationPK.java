package travail;

import java.io.Serializable;
import java.util.Objects;

public class ReparationPK implements Serializable {

    private static final long serialVersionUID = 1L;

    private int avion;
    private int technicien;

    // Constructeurs
    public ReparationPK() {}

    public ReparationPK(int avion, int technicien) {
        this.avion = avion;
        this.technicien = technicien;
    }

    // Getters et Setters
    public int getAvionMatricule() {
        return avion;
    }

    public void setAvionMatricule(int avion) {
        this.avion = avion;
    }

    public int getTechnicienMatricule() {
        return technicien;
    }

    public void setTechnicienMatricule(int technicien) {
        this.technicien = technicien;
    }

    // Override equals et hashCode
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ReparationPK that = (ReparationPK) o;
        return avion == that.avion && technicien == that.technicien;
    }

    @Override
    public int hashCode() {
        return Objects.hash(avion, technicien);
    }
}
