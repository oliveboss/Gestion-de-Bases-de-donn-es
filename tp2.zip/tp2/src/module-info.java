/**
 * 
 */
/**
 * 
 */
module tp2 {
	requires org.hibernate.orm.core;
	requires java.sql;
	requires java.persistence; 
    opens travail to org.hibernate.orm.core, org.hibernate.validator,org.hibernate.search.mapper.orm; // Ajuste "travail" à ton package exact


     
	
	requires java.base;
	requires java.validation;
	requires org.hibernate.search.mapper.pojo;
	requires org.hibernate.search.mapper.orm; // Si tu utilises Hibernate Validator
}